﻿using CRUDOperationCodeFirst.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace CRUDOperationCodeFirst.DAL
{
    public class EmployeeContext : DbContext
    {
        public EmployeeContext()
            : base("PassionContext")
        {
        }

        public DbSet<Employees> Employees { get; set; }
        public DbSet<Admins> Admins { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {   
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }
    }
}