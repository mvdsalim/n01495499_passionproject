﻿using CRUDOperationCodeFirst.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CRUDOperationCodeFirst.DAL
{
    //public class DepartmentInitializer : System.Data.Entity.DropCreateDatabaseIfModelChanges<EmployeeContext>
    public class DepartmentInitializer : System.Data.Entity.DropCreateDatabaseAlways<EmployeeContext>
    {
        protected override void Seed(EmployeeContext context)
        {
            //admins (by default its 1, but we can add more than 1)
            var admins = new List<Admins>
            {
            new Admins{Id=1,FirstName="Test",LastName="Admin",Username="Admin",Password="Admin@123",CreatedDate=DateTime.Now}
            };
            admins.ForEach(s => context.Admins.Add(s));
            context.SaveChanges();


            // Employee
            var Employees = new List<Employees>
            {
            new Employees{Id=1,FirstName="Minas",LastName="Sinha",Designation=".net junior Developer",Username="Employee1",Password="Employee@123",CreatedDate=DateTime.Now},
            new Employees{Id=2,FirstName="Kamal",LastName="Nagpal",Designation="PHP developer",Username="Employee2",Password="Employee@123",CreatedDate=DateTime.Now},
            new Employees{Id=3,FirstName="Lyle",LastName="Chandel",Designation="Team Lead",Username="Employee3",Password="Employee@123",CreatedDate=DateTime.Now}

            };
            Employees.ForEach(s => context.Employees.Add(s));
            context.SaveChanges();
        }
    }
}