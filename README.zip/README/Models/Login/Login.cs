﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CRUDOperationCodeFirst.Models.Login
{
    public class Login
    {
        [Required]
        [MinLength(1)]
        public string UserName { get; set; }
        [Required]
        [MinLength(1)]
        public string Password { get; set; }
    }
}