﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CRUDOperationCodeFirst.Models
{
    public class Employees : BaseModel
    {
        public string Designation { get; set; }

        public int Salary { get; set; }
    }
}