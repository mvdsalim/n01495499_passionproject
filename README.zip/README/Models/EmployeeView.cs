﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CRUDOperationCodeFirst.Models
{
    public class EmployeeView
    {
        public Employees Employee { get; set; }
    }
}