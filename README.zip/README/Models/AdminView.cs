﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CRUDOperationCodeFirst.Models
{
    public class AdminView
    {
        public Admins Admin { get; set; }
        public List<Employees> Employees { get; set; }
    }
}