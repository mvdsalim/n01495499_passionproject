﻿using CRUDOperationCodeFirst.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CRUDOperationCodeFirst.Models.Login;

namespace CRUDOperationCodeFirst.Controllers
{
    [AllowAnonymous]
    public class LoginController : Controller
    {
        private EmployeeContext db = new EmployeeContext();
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult Login()
        {
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ActionResult Signout()
        {
            Session.Clear();
            Session.Abandon();
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(Login objUser)
        {
            if (ModelState.IsValid) 
            {
                ViewBag.Error = "";
                var obj = db.Admins.Where(a => a.Username.Equals(objUser.UserName) && a.Password.Equals(objUser.Password)).FirstOrDefault();
                if (obj != null)
                {
                    Session["UserID"] = obj.Id.ToString();
                    Session["UserName"] = obj.Username.ToString();
                    Session["Name"] = obj.FirstName.ToString() + " "+ obj.LastName.ToString();
                    Session["Role"] = "Admin";
                    return RedirectToAction("Index","Admin");
                }
                var obj1 = db.Employees.Where(a => a.Username.Equals(objUser.UserName) && a.Password.Equals(objUser.Password)).FirstOrDefault();
                if (obj1 != null)
                {
                    Session["UserID"] = obj1.Id.ToString();
                    Session["UserName"] = obj1.Username.ToString();
                    Session["Name"] = obj1.FirstName.ToString() + " " + obj1.LastName.ToString();
                    Session["Role"] = "Employee";
                    return RedirectToAction("Index", "Employee");
                }
            }
            ViewBag.Error = "Invalid Credentials !!";
            return View("Index");
        }
    }
}