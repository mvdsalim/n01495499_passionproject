﻿using CRUDOperationCodeFirst.DAL;
using CRUDOperationCodeFirst.Models;
using System;
using System.Net;
using System.Web.Mvc;

namespace CRUDOperationCodeFirst.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly EmployeeContext db = new EmployeeContext();
        // GET: Employee
        public ActionResult Index()
        {
            int? id = Convert.ToInt32(Session["UserID"].ToString());
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employees Employee = db.Employees.Find(id);
            if (Employee == null)
            {
                return HttpNotFound();
            }
            EmployeeView dp = new EmployeeView();
            dp.Employee = Employee;
            ViewBag.isEmployee = true;
            return View(dp);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

    }
}