﻿using CRUDOperationCodeFirst.DAL;
using CRUDOperationCodeFirst.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Web.Mvc;

namespace CRUDOperationCodeFirst.Controllers
{  
    public class AdminController : Controller
    {
        private EmployeeContext db = new EmployeeContext();
        [NonAction]
        public string Employee(Employees d)
        {
            if (d == null) return "";
            return d.FirstName + " " + d.LastName + " (" + d.Designation + ")";

        }
        // GET: Admin
        public ActionResult Index()
        {
            int? id = Convert.ToInt32(Session["UserID"].ToString());
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Admins Admin = db.Admins.Find(id);
            if (Admin == null)
            {
                return HttpNotFound();
            }
           
            List<Employees> Employees = db.Employees.ToList();



            AdminView da = new AdminView();
            da.Employees = Employees;
            da.Admin = Admin;
            return View(da);
        }
        public ActionResult EditAdmin(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Admins Admin = db.Admins.Find(id);
            if (Admin == null)
            {
                return HttpNotFound();
            }
            return View(Admin);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditAdmin(Admins admin)
        {
            if (ModelState.IsValid)
            {
                db.Entry(admin).State = EntityState.Modified;
                db.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employees Employee = db.Employees.Find(id);
            if (Employee == null)
            {
                return HttpNotFound();
            }
            ViewBag.isEmployee = false;
            return View("ViewEmployee", Employee);
        }
        public ActionResult Create()
        {
            return View("CreateEmployee");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Employees Employee)
        {
            if (ModelState.IsValid)
            {
                db.Employees.Add(Employee);
                db.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employees Employee = db.Employees.Find(id);
            if (Employee == null)
            {
                return HttpNotFound();
            }
            return View("EditEmployee", Employee);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Employees Employee)
        {
            if (ModelState.IsValid)
            {
                db.Entry(Employee).State = EntityState.Modified;
                db.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employees Employee = db.Employees.Find(id);
            if (Employee == null)
            {
                return HttpNotFound();
            }
            
            return View("DeleteEmployee", Employee);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Employees Employee = db.Employees.Find(id);
            db.Employees.Remove(Employee);           
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}